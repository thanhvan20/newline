import sys
import json
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin

_url = sys.argv[0]
_handle = int(sys.argv[1])

# URL chứa thông tin thư viện và thông tin mã PIN
LIBRARY_DETAILS_URL = "https://a-z.azdata.workers.dev/kodimain.json"
PIN_CODES_URL = "https://a-z.azdata.workers.dev/kodiprivate.json"  # URL chứa mã PIN

# Tạo một dictionary để lưu trạng thái đã xác minh mã PIN
verified_pins = {}

# Hàm tải dữ liệu JSON từ URL với header User-Agent
def load_json(json_url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        request = Request(json_url, headers=headers)
        xbmc.log(f"Trying to load JSON data from: {json_url}", xbmc.LOGINFO)
        
        with urlopen(request) as response:
            data = json.load(response)
            xbmc.log("Successfully loaded JSON data.", xbmc.LOGINFO)
            return data
    except HTTPError as e:
        xbmc.log(f"HTTPError: {e.code} - {e.reason}", xbmc.LOGERROR)
    except URLError as e:
        xbmc.log(f"URLError: {e.reason}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Unexpected error: {str(e)}", xbmc.LOGERROR)
    return {}

def load_pin_codes():
    """Tải mã PIN từ URL"""
    global PIN_CODES
    pin_codes = load_json(PIN_CODES_URL)
    if pin_codes:
        PIN_CODES.update(pin_codes)  # Cập nhật PIN_CODES từ dữ liệu tải về
        xbmc.log("Successfully loaded PIN codes.", xbmc.LOGINFO)
    else:
        xbmc.log("Failed to load PIN codes.", xbmc.LOGERROR)

# Khởi tạo PIN_CODES khi bắt đầu
PIN_CODES = {}
load_pin_codes()

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def ask_for_pin(library_name):
    """Hiển thị hộp thoại yêu cầu nhập mã PIN và kiểm tra mã PIN của thư viện tương ứng."""
    # Nếu danh mục không yêu cầu mã PIN, bỏ qua kiểm tra
    if library_name not in PIN_CODES:
        xbmc.log(f"No PIN required for {library_name}", xbmc.LOGINFO)
        return True

    # Kiểm tra nếu mã PIN đã được xác minh trước đó
    if library_name in verified_pins and verified_pins[library_name]:
        return True  # Nếu đã xác minh mã PIN, cho phép truy cập ngay lập tức

    pin_dialog = xbmcgui.Dialog()
    
    # Hiển thị hộp thoại yêu cầu người dùng nhập mã PIN
    pin = pin_dialog.numeric(0, f"Nhập mã PIN cho {library_name}:")
    
    xbmc.log(f"Entered PIN: {pin}", xbmc.LOGINFO)  # Log mã PIN người dùng nhập vào
    
    # Lấy mã PIN yêu cầu từ PIN_CODES
    pin_required = PIN_CODES.get(library_name)
    
    # Kiểm tra mã PIN
    if pin_required and str(pin) == str(pin_required):  # Chuyển cả hai thành chuỗi trước khi so sánh
        verified_pins[library_name] = True  # Lưu trạng thái đã xác minh
        return True
    else:
        # Hiển thị thông báo nếu mã PIN sai
        xbmcgui.Dialog().notification("Access Denied", "Incorrect PIN", xbmcgui.NOTIFICATION_ERROR)
        return False

def main_menu():
    """Hiển thị menu chính."""
    library_details = load_json(LIBRARY_DETAILS_URL)
    if not library_details:
        xbmcgui.Dialog().notification("Error", "Failed to load library details.", xbmcgui.NOTIFICATION_ERROR)
        return

    for library_name, details in library_details.items():
        li = xbmcgui.ListItem(library_name)
        li.setArt({'poster': details.get('poster', '')})  # Thêm poster
        li.setInfo('video', {'title': library_name, 'plot': details.get('description', '')})  # Thêm nội dung mô tả
        url = get_url(action='list_library', library_name=library_name)
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle)

def build_libraries():
    """Xây dựng danh sách LIBRARIES từ LIBRARY_DETAILS_URL."""
    library_details = load_json(LIBRARY_DETAILS_URL)
    if not library_details:
        xbmc.log("Failed to load library details for building LIBRARIES.", xbmc.LOGERROR)
        return {}

    libraries = {}
    for library_name, details in library_details.items():
        data_json = details.get("data_json")
        if data_json:
            libraries[library_name] = data_json
    return libraries

def list_videos(library_name):
    """Hiển thị danh sách video từ thư viện được chọn."""
    # Kiểm tra mã PIN cho thư viện trước khi tiếp tục
    if not ask_for_pin(library_name):
        return

    libraries = build_libraries()
    json_url = libraries.get(library_name, "")
    if not json_url:
        xbmc.log(f"Library {library_name} not found.", xbmc.LOGERROR)
        return
    videos = load_json(json_url)
    if not videos:
        xbmc.log(f"No videos found in {library_name}.", xbmc.LOGINFO)
        return
    
    for video in videos:
        if 'url' in video:
            li = xbmcgui.ListItem(video['name'])
            li.setArt({'poster': video['poster_url']})
            li.setInfo('video', {'title': video['name'], 'plot': video['description']})
            li.setProperty('IsPlayable', 'true')
            url = get_url(action='play', video_url=video['url'])
            xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)
        elif 'links' in video:
            li = xbmcgui.ListItem(video['name'])
            li.setArt({'poster': video['poster_url']})
            li.setInfo('video', {'title': video['name'], 'plot': video['description']})
            url = get_url(action='list_links', video_name=video['name'], library_name=library_name)
            xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle)

def list_links(video_name, library_name):
    """Hiển thị danh sách các liên kết trong video."""
    libraries = build_libraries()
    json_url = libraries.get(library_name, "")
    videos = load_json(json_url)
    keywords = ["vietsub", "viet_sub", "sub viet", "viet sub", "phụ đề", "sub", "viet","hardsub"]
    for video in videos:
        if video['name'] == video_name and 'links' in video:
            for link in video['links']:
                file_name = link['file_name']
                quality_colored = f"[COLOR yellow]{link['quality']}[/COLOR]"
                highlighted_name = file_name
                for keyword in keywords:
                    highlighted_name = highlighted_name.replace(
                        keyword, f"[COLOR yellow]{keyword}[/COLOR]"
                    ).replace(
                        keyword.capitalize(), f"[COLOR yellow]{keyword.capitalize()}[/COLOR]"
                    ).replace(
                        keyword.upper(), f"[COLOR yellow]{keyword.upper()}[/COLOR]"
                    )
                label = f"{highlighted_name} - {quality_colored}"
                li = xbmcgui.ListItem(label)
                li.setArt({'poster': video['poster_url']})
                li.setInfo('video', {'title': video['name'], 'plot': video['description']})
                li.setProperty('IsPlayable', 'true')
                url = get_url(action='play', video_url=link['url'])
                xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle)

def play_video(video_url):
    """Phát video."""
    xbmc.log(f"Playing video: {video_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=video_url)
    li.setMimeType("video/mp4")
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(_handle, True, li)

def router(paramstring):
    """Điều hướng yêu cầu."""
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    
    if action == 'list_library':
        library_name = params.get('library_name')
        list_videos(library_name)
    elif action == 'list_links':
        video_name = params.get('video_name')
        library_name = params.get('library_name')
        list_links(video_name, library_name)
    elif action == 'play':
        video_url = params.get('video_url')
        play_video(video_url)
    else:
        main_menu()

# Điều hướng yêu cầu từ Kodi
router(sys.argv[2][1:])

